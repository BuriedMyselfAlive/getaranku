// ignore_for_file: camel_case_types

import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';

@RoutePage()
class details extends StatelessWidget {
  const details({super.key, 
    required this.title,
    required this.detail,
  });

  final String title;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(detail),
      ),
    );
  }
}