// ignore_for_file: camel_case_types

import 'package:auto_route/auto_route.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:getaranku/screen/details.dart';

@RoutePage()
class history extends StatelessWidget {
  const history({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
      ),
      body: StreamBuilder<DatabaseEvent>(
        stream: FirebaseDatabase.instance.ref().child('history').onValue,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final data = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
            final historyList = data.values.toList();

            return ListView.builder(
              itemCount: historyList.length,
              itemBuilder: (context, index) {
                final item = historyList[index] as Map<String, dynamic>;

                return GestureDetector(
                  onTap: () {
                    // Handle details display (e.g., navigate to a details page)
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => details(
                          title: item['int'],
                          detail: item['details'],
                        ),
                      ),
                    );
                  },
                  child: ListTile(
                    title: Text(item['int']),
                    // Add other UI elements as needed
                  ),
                );
              },
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}