// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i4;
import 'package:getaranku/screen/details.dart' as _i1;
import 'package:getaranku/screen/history.dart' as _i2;
import 'package:getaranku/screen/index.dart' as _i3;

abstract class $AppRouter extends _i4.RootStackRouter {
  $AppRouter({super.navigatorKey});

  @override
  final Map<String, _i4.PageFactory> pagesMap = {
    Details.name: (routeData) {
      return _i4.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i1.details(title: '', detail: '',),
      );
    },
    History.name: (routeData) {
      return _i4.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i2.history(),
      );
    },
    Index.name: (routeData) {
      return _i4.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i3.index(),
      );
    },
  };
}

/// generated route for
/// [_i1.details]
class Details extends _i4.PageRouteInfo<void> {
  const Details({List<_i4.PageRouteInfo>? children})
      : super(
          Details.name,
          initialChildren: children,
        );

  static const String name = 'Details';

  static const _i4.PageInfo<void> page = _i4.PageInfo<void>(name);
}

/// generated route for
/// [_i2.history]
class History extends _i4.PageRouteInfo<void> {
  const History({List<_i4.PageRouteInfo>? children})
      : super(
          History.name,
          initialChildren: children,
        );

  static const String name = 'History';

  static const _i4.PageInfo<void> page = _i4.PageInfo<void>(name);
}

/// generated route for
/// [_i3.index]
class Index extends _i4.PageRouteInfo<void> {
  const Index({List<_i4.PageRouteInfo>? children})
      : super(
          Index.name,
          initialChildren: children,
        );

  static const String name = 'Index';

  static const _i4.PageInfo<void> page = _i4.PageInfo<void>(name);
}
